<?php
include("db.php");

$data = null;

if(isset($_POST['search']))
{
    $vehicle_number = strtoupper($_POST['vehicle_number']);

    $result = mysqli_query($conn,"SELECT * FROM vehicles
    WHERE vehicle_number='$vehicle_number'
    ORDER BY vehicle_id DESC
    LIMIT 1");

    if(mysqli_num_rows($result)>0)
    {
        $data = mysqli_fetch_assoc($result);
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Parking Bill</title>

<link rel="stylesheet" href="css/style.css">

<style>

.bill{
    width:500px;
    margin:30px auto;
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 0 10px gray;
}

.bill table{
    width:100%;
    border-collapse:collapse;
}

.bill table td{
    padding:10px;
    border:1px solid #ddd;
}

.bill h2{
    text-align:center;
    margin-bottom:20px;
}

</style>

</head>

<body>

<div class="form-box">

<h2>🧾 Parking Bill</h2>

<form method="POST">

<input
type="text"
name="vehicle_number"
placeholder="Enter Vehicle Number"
required>

<input
type="submit"
name="search"
value="Search Bill">

</form>

</div>

<?php

if($data)
{

?>

<div class="bill">

<h2>Parking Receipt</h2>

<table>

<tr>
<td><b>Owner Name</b></td>
<td><?php echo $data['owner_name']; ?></td>
</tr>

<tr>
<td><b>Mobile</b></td>
<td><?php echo $data['mobile_no']; ?></td>
</tr>

<tr>
<td><b>Vehicle Number</b></td>
<td><?php echo $data['vehicle_number']; ?></td>
</tr>

<tr>
<td><b>Vehicle Type</b></td>
<td><?php echo $data['vehicle_type']; ?></td>
</tr>

<tr>
<td><b>Entry Time</b></td>
<td><?php echo $data['entry_time']; ?></td>
</tr>

<tr>
<td><b>Exit Time</b></td>
<td><?php echo $data['exit_time']; ?></td>
</tr>

<tr>
<td><b>Parking Charge</b></td>
<td>₹ <?php echo $data['parking_charge']; ?></td>
</tr>

<tr>
<td><b>Status</b></td>
<td><?php echo $data['status']; ?></td>
</tr>

</table>

</div>

<?php

}

?>

<br>

<center>

<a href="admin/dashboard.php">⬅ Back To Dashboard</a>

</center>

</body>
</html>
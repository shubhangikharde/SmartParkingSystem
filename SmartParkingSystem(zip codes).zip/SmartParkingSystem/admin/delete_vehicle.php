<?php
session_start();

if(!isset($_SESSION['admin']))
{
    header("Location: login.php");
    exit();
}

include("../db.php");

if(isset($_GET['id']))
{
    $id = $_GET['id'];

    // Slot ID shodha
    $result = mysqli_query($conn,
    "SELECT slot_id FROM vehicles WHERE vehicle_id='$id'");

    if(mysqli_num_rows($result)>0)
    {
        $row = mysqli_fetch_assoc($result);

        $slot_id = $row['slot_id'];

        // Vehicle delete kara
        mysqli_query($conn,
        "DELETE FROM vehicles WHERE vehicle_id='$id'");

        // Slot Available kara
        mysqli_query($conn,
        "UPDATE parking_slots
        SET status='Available'
        WHERE slot_id='$slot_id'");
    }
}

header("Location:view_vehicles.php");
exit();
?>
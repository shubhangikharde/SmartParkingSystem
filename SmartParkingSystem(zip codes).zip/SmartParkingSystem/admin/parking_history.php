<?php
error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:login.php");
    exit();
}

include("../db.php");

$sql="SELECT v.*,p.slot_number
FROM vehicles v
INNER JOIN parking_slots p
ON v.slot_id=p.slot_id
WHERE v.status='Exited'
ORDER BY v.vehicle_id DESC";

$result=mysqli_query($conn,$sql);
?>

<!DOCTYPE html>
<html>

<head>

<title>Parking History</title>

<style>

body{
    font-family:Arial;
    background:#f4f4f4;
}

.container{
    width:95%;
    margin:auto;
    margin-top:30px;
}

h2{
    text-align:center;
    color:#0d6efd;
}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
}

table,th,td{
    border:1px solid #ddd;
}

th{
    background:#0d6efd;
    color:white;
    padding:12px;
}

td{
    text-align:center;
    padding:10px;
}

tr:nth-child(even){
    background:#f9f9f9;
}

.back{
    text-align:center;
    margin-top:20px;
}

.back a{
    text-decoration:none;
    background:#0d6efd;
    color:white;
    padding:10px 20px;
    border-radius:5px;
}

</style>

</head>

<body>

<div class="container">

<h2>📜 Parking History</h2>

<table>

<tr>

<th>ID</th>
<th>Owner</th>
<th>Mobile</th>
<th>Vehicle Number</th>
<th>Vehicle Type</th>
<th>Slot</th>
<th>Entry Time</th>
<th>Exit Time</th>
<th>Charge</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['vehicle_id']; ?></td>

<td><?php echo $row['owner_name']; ?></td>

<td><?php echo $row['mobile_no']; ?></td>

<td><?php echo $row['vehicle_number']; ?></td>

<td><?php echo $row['vehicle_type']; ?></td>

<td><?php echo $row['slot_number']; ?></td>

<td><?php echo $row['entry_time']; ?></td>

<td><?php echo $row['exit_time']; ?></td>

<td>₹ <?php echo $row['parking_charge']; ?></td>

</tr>

<?php

}

?>

</table>

<div class="back">

<br>

<a href="dashboard.php">⬅ Back To Dashboard</a>

</div>

</div>

</body>

</html>
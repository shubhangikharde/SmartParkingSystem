<?php
session_start();
include("../db.php");

$message="";

if(isset($_POST['login']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];

    $result=mysqli_query($conn,"SELECT * FROM admin
    WHERE username='$username'
    AND password='$password'");

    if(mysqli_num_rows($result)>0)
    {
        $_SESSION['admin']=$username;
        header("Location: dashboard.php");
        exit();
    }
    else
    {
        $message="Invalid Username or Password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Admin Login</title>

<link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="form-box">

<h2>Admin Login</h2>

<?php
if($message!="")
{
    echo "<p class='success'>$message</p>";
}
?>

<form method="POST">

<input
type="text"
name="username"
placeholder="Username"
required>

<input
type="password"
name="password"
placeholder="Password"
required>

<input
type="submit"
name="login"
value="Login">

</form>

<br>

<a href="../index.php">⬅ Back To Home</a>

</div>

</body>
</html>
<?php
session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:login.php");
    exit();
}

include("../db.php");

$id=$_GET['id'];

$result=mysqli_query($conn,"SELECT * FROM vehicles WHERE vehicle_id='$id'");
$row=mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{
    $owner=$_POST['owner_name'];
    $mobile=$_POST['mobile_no'];

    mysqli_query($conn,"UPDATE vehicles
    SET owner_name='$owner',
        mobile_no='$mobile'
    WHERE vehicle_id='$id'");

    header("Location:view_vehicles.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Edit Vehicle</title>

<style>

body{
    font-family:Arial;
    background:#f4f4f4;
}

.box{
    width:400px;
    margin:50px auto;
    background:white;
    padding:25px;
    border-radius:10px;
}

input{
    width:100%;
    padding:10px;
    margin:10px 0;
}

input[type=submit]{
    background:#0d6efd;
    color:white;
    border:none;
    cursor:pointer;
}

</style>

</head>

<body>

<div class="box">

<h2>Edit Vehicle</h2>

<form method="POST">

<label>Owner Name</label>

<input
type="text"
name="owner_name"
value="<?php echo $row['owner_name']; ?>">

<label>Mobile Number</label>

<input
type="text"
name="mobile_no"
value="<?php echo $row['mobile_no']; ?>">

<input
type="submit"
name="update"
value="Update Vehicle">

</form>

<br>

<a href="view_vehicles.php">⬅ Back</a>

</div>

</body>
</html>
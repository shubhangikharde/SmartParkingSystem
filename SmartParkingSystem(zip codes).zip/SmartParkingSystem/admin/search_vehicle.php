<?php
session_start();

if(!isset($_SESSION['admin']))
{
    header("Location: login.php");
    exit();
}

include("../db.php");

$result = null;

if(isset($_POST['search']))
{
    $vehicle_number = strtoupper(trim($_POST['vehicle_number']));

    $sql = "SELECT v.*, p.slot_number
            FROM vehicles v
            INNER JOIN parking_slots p
            ON v.slot_id = p.slot_id
            WHERE v.vehicle_number='$vehicle_number'";

    $query = mysqli_query($conn,$sql);

    if(mysqli_num_rows($query)>0)
    {
        $result = mysqli_fetch_assoc($query);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Search Vehicle</title>

<style>

body{
    font-family:Arial;
    background:#f4f4f4;
}

.container{
    width:70%;
    margin:auto;
    margin-top:30px;
    background:white;
    padding:20px;
    border-radius:10px;
}

h2{
    text-align:center;
    color:#0d6efd;
}

input[type=text]{
    width:60%;
    padding:10px;
}

input[type=submit]{
    padding:10px 20px;
    background:#0d6efd;
    color:white;
    border:none;
    cursor:pointer;
}

table{
    width:100%;
    margin-top:20px;
    border-collapse:collapse;
}

table,th,td{
    border:1px solid #ddd;
}

th{
    background:#0d6efd;
    color:white;
    padding:10px;
}

td{
    padding:10px;
    text-align:center;
}

.back{
    margin-top:20px;
    text-align:center;
}

.back a{
    text-decoration:none;
    background:#0d6efd;
    color:white;
    padding:10px 20px;
    border-radius:5px;
}

</style>

</head>

<body>

<div class="container">

<h2>🔍 Search Vehicle</h2>

<form method="POST" align="center">

<input type="text" name="vehicle_number"
placeholder="Enter Vehicle Number" required>

<input type="submit" name="search" value="Search">

</form>

<?php

if($result)
{

?>

<table>

<tr>

<th>ID</th>
<th>Owner</th>
<th>Mobile</th>
<th>Vehicle No</th>
<th>Type</th>
<th>Slot</th>
<th>Status</th>

</tr>

<tr>

<td><?php echo $result['vehicle_id']; ?></td>
<td><?php echo $result['owner_name']; ?></td>
<td><?php echo $result['mobile_no']; ?></td>
<td><?php echo $result['vehicle_number']; ?></td>
<td><?php echo $result['vehicle_type']; ?></td>
<td><?php echo $result['slot_number']; ?></td>
<td><?php echo $result['status']; ?></td>

</tr>

</table>

<?php

}
elseif(isset($_POST['search']))
{
    echo "<h3 style='text-align:center;color:red;'>Vehicle Not Found!</h3>";
}

?>

<div class="back">

<br>

<a href="dashboard.php">⬅ Back To Dashboard</a>

</div>

</div>

</body>
</html>
<?php
session_start();

if(!isset($_SESSION['admin']))
{
    header("Location: login.php");
    exit();
}

include("../db.php");

// Total Vehicles
$total = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total FROM vehicles"))['total'];

// Parked Vehicles
$parked = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total FROM vehicles WHERE status='Parked'"))['total'];

// Exited Vehicles
$exited = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total FROM vehicles WHERE status='Exited'"))['total'];

// Available Slots
$available = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total FROM parking_slots WHERE status='Available'"))['total'];

// Occupied Slots
$occupied = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total FROM parking_slots WHERE status='Occupied'"))['total'];

// Revenue
$revenue = mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(parking_charge) AS total FROM vehicles"))['total'];

if($revenue=="")
{
    $revenue=0;
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Admin Dashboard</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    background:#f4f6f9;
    text-align:center;
}

.header{
    background:#0d6efd;
    color:white;
    padding:20px;
    font-size:35px;
    font-weight:bold;
}

.sub{
    margin:15px;
    color:#555;
    font-size:18px;
}

.box{
    width:250px;
    display:inline-block;
    margin:15px;
    padding:25px;
    background:white;
    border-radius:12px;
    box-shadow:0 0 12px rgba(0,0,0,0.2);
    transition:.3s;
}

.box:hover{
    transform:translateY(-5px);
}

.box h3{
    color:#0d6efd;
    margin-bottom:15px;
}

.box p{
    font-size:35px;
    font-weight:bold;
    color:#333;
}

.menu{
    width:90%;
    margin:30px auto;
}

.menu a{
    display:inline-block;
    width:220px;
    margin:10px;
    padding:14px;
    background:#0d6efd;
    color:white;
    text-decoration:none;
    border-radius:8px;
    font-size:17px;
    font-weight:bold;
    transition:.3s;
}

.menu a:hover{
    background:#084298;
    transform:scale(1.05);
}

.footer{
    margin-top:40px;
    background:#0d6efd;
    color:white;
    padding:15px;
}

</style>

</head>

<body>

<div class="header">
🚗 Smart Parking Management System
</div>

<div class="sub">
Welcome Admin
</div>

<div class="box">
<h3>🚗 Total Vehicles</h3>
<p><?php echo $total; ?></p>
</div>

<div class="box">
<h3>🅿 Parked Vehicles</h3>
<p><?php echo $parked; ?></p>
</div>

<div class="box">
<h3>🚪 Exited Vehicles</h3>
<p><?php echo $exited; ?></p>
</div>

<div class="box">
<h3>✅ Available Slots</h3>
<p><?php echo $available; ?></p>
</div>

<div class="box">
<h3>❌ Occupied Slots</h3>
<p><?php echo $occupied; ?></p>
</div>

<div class="box">
<h3>💰 Revenue</h3>
<p>₹ <?php echo $revenue; ?></p>
</div>

<div class="menu">

<a href="../vehicle_entry.php">🚘 Vehicle Entry</a>

<a href="../available_slots.php">🅿 Available Slots</a>

<a href="../vehicle_exit.php">🚪 Vehicle Exit</a>

<a href="../parking_bill.php">🧾 Parking Bill</a>

<a href="view_vehicles.php">📋 View Vehicles</a>

<a href="search_vehicle.php">🔍 Search Vehicle</a>

<a href="parking_history.php">📜 Parking History</a>

<a href="current_vehicles.php">🚗 Current Vehicles</a>

<a href="logout.php">🚪 Logout</a>

</div>

<div class="footer">
© 2026 Smart Parking Management System | Admin Dashboard
</div>

</body>
</html>
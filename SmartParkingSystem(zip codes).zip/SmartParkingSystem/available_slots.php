<?php
include("db.php");

$result = mysqli_query($conn,"SELECT * FROM parking_slots");
?>

<!DOCTYPE html>
<html>
<head>

<title>Available Slots</title>

<link rel="stylesheet" href="css/style.css">

<style>

table{
    width:70%;
    margin:auto;
    margin-top:30px;
    border-collapse:collapse;
}

table,th,td{
    border:1px solid black;
}

th{
    background:#0d6efd;
    color:white;
    padding:12px;
}

td{
    text-align:center;
    padding:10px;
}

.available{
    color:green;
    font-weight:bold;
}

.occupied{
    color:red;
    font-weight:bold;
}

h2{
    text-align:center;
    margin-top:30px;
}

.back{
    display:block;
    text-align:center;
    margin-top:25px;
    font-size:18px;
}

</style>

</head>

<body>

<h2>🚗 Parking Slots Status</h2>

<table>

<tr>

<th>Slot ID</th>

<th>Slot Number</th>

<th>Vehicle Type</th>

<th>Status</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['slot_id']; ?></td>

<td><?php echo $row['slot_number']; ?></td>

<td><?php echo $row['slot_type']; ?></td>

<td>

<?php

if($row['status']=="Available")
{
    echo "<span class='available'>Available</span>";
}
else
{
    echo "<span class='occupied'>Occupied</span>";
}

?>

</td>

</tr>

<?php

}

?>

</table>

<a class="back" href="admin/dashboard.php">⬅ Back To Dashboard</a>

</body>

</html>
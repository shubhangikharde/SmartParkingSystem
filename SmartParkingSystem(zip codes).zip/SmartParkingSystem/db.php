<?php
$conn = mysqli_connect("localhost","root","shubhangi@19","smart_parking");

if(!$conn){
    die("Connection Failed: ".mysqli_connect_error());
}
?>
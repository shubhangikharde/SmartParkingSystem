<?php
include("db.php");

$message="";

if(isset($_POST['exit']))
{
    $vehicle_number = strtoupper($_POST['vehicle_number']);

    $result = mysqli_query($conn,"SELECT * FROM vehicles
    WHERE vehicle_number='$vehicle_number' AND status='Parked'");

    if(mysqli_num_rows($result)>0)
    {
        $vehicle = mysqli_fetch_assoc($result);

        $vehicle_id = $vehicle['vehicle_id'];
        $slot_id = $vehicle['slot_id'];
        $entry_time = strtotime($vehicle['entry_time']);
        $exit_time = date("Y-m-d H:i:s");

        $hours = ceil((time() - $entry_time)/3600);

        if($hours<=2)
            $charge = ($vehicle['vehicle_type']=="Bike") ? 20 : 30;
        elseif($hours<=5)
            $charge = ($vehicle['vehicle_type']=="Bike") ? 40 : 60;
        else
            $charge = ($vehicle['vehicle_type']=="Bike") ? 80 : 120;

        mysqli_query($conn,"UPDATE vehicles
        SET
        exit_time='$exit_time',
        parking_charge='$charge',
        status='Exited'
        WHERE vehicle_id='$vehicle_id'");

        mysqli_query($conn,"UPDATE parking_slots
        SET status='Available'
        WHERE slot_id='$slot_id'");

        $message="Vehicle Exited Successfully!<br>Total Charge : ₹".$charge;
    }
    else
    {
        $message="Vehicle Not Found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Vehicle Exit</title>

<link rel="stylesheet" href="css/style.css">

</head>

<body>

<div class="form-box">

<h2>🚗 Vehicle Exit</h2>

<?php
if($message!="")
{
    echo "<p class='success'>$message</p>";
}
?>

<form method="POST">

<input
type="text"
name="vehicle_number"
placeholder="Vehicle Number"
required>

<input
type="submit"
name="exit"
value="Exit Vehicle">

</form>

<br>

<a href="admin/dashboard.php">⬅ Back To Dashboard</a>

</div>

</body>
</html>
<?php
include("db.php");

$message = "";

if(isset($_POST['submit']))
{
    $owner_name = $_POST['owner_name'];
    $mobile_no = $_POST['mobile_no'];
    $vehicle_number = strtoupper($_POST['vehicle_number']);
    $vehicle_type = $_POST['vehicle_type'];

    // Find Available Slot
    $slot = mysqli_query($conn,"SELECT * FROM parking_slots 
    WHERE slot_type='$vehicle_type' AND status='Available' LIMIT 1");

    if(mysqli_num_rows($slot)>0)
    {
        $data = mysqli_fetch_assoc($slot);

        $slot_id = $data['slot_id'];
        $slot_number = $data['slot_number'];

        // Insert Vehicle
        mysqli_query($conn,"INSERT INTO vehicles
        (owner_name,mobile_no,vehicle_number,vehicle_type,slot_id)
        VALUES
        ('$owner_name','$mobile_no','$vehicle_number','$vehicle_type','$slot_id')");

        // Update Slot Status
        mysqli_query($conn,"UPDATE parking_slots
        SET status='Occupied'
        WHERE slot_id='$slot_id'");

        $message = "Vehicle Parked Successfully!<br>Allocated Slot : <b>$slot_number</b>";
    }
    else
    {
        $message = "No Parking Slot Available!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Vehicle Entry</title>

<link rel="stylesheet" href="css/style.css">

</head>

<body>

<div class="form-box">

<h2>🚗 Vehicle Entry</h2>

<?php
if($message!="")
{
    echo "<p class='success'>$message</p>";
}
?>

<form method="POST">

<input type="text"
name="owner_name"
placeholder="Owner Name"
required>

<input type="text"
name="mobile_no"
placeholder="Mobile Number"
required>

<input type="text"
name="vehicle_number"
placeholder="Vehicle Number"
required>

<select name="vehicle_type" required>

<option value="">Select Vehicle</option>

<option value="Bike">Bike</option>

<option value="Car">Car</option>

</select>

<input type="submit"
name="submit"
value="Park Vehicle">

</form>

<br>
<a href="admin/dashboard.php">⬅ Back To Dashboard</a>

</div>

</body>
</html>
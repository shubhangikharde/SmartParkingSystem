<!DOCTYPE html>
<html>
<head>
<title>Smart Parking Management System</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    background:#f2f6fc;
}

.header{
    background:#0d6efd;
    color:white;
    text-align:center;
    padding:25px;
    font-size:34px;
    font-weight:bold;
    letter-spacing:1px;
}

.subheading{
    text-align:center;
    color:#555;
    margin-top:15px;
    font-size:18px;
}

.container{
    width:420px;
    margin:35px auto;
    background:white;
    padding:30px;
    border-radius:12px;
    box-shadow:0 0 15px rgba(0,0,0,0.2);
}

.btn{
    display:block;
    width:100%;
    text-align:center;
    text-decoration:none;
    background:#0d6efd;
    color:white;
    padding:14px;
    margin:15px 0;
    border-radius:8px;
    font-size:18px;
    transition:0.3s;
}

.btn:hover{
    background:#084298;
    transform:scale(1.03);
}

.footer{
    text-align:center;
    margin-top:30px;
    color:#666;
    font-size:15px;
}

</style>

</head>

<body>

<div class="header">
🚗 Smart Parking Management System
</div>

<div class="subheading">
Fast • Secure • Easy Parking
</div>

<div class="container">

<a href="vehicle_entry.php" class="btn">🚘 Vehicle Entry</a>

<a href="available_slots.php" class="btn">🅿 Available Slots</a>

<a href="vehicle_exit.php" class="btn">🚪 Vehicle Exit</a>

<a href="parking_bill.php" class="btn">🧾 Parking Bill</a>

<a href="admin/login.php" class="btn">🔐 Admin Login</a>

</div>

<div class="footer">
© 2026 Smart Parking Management System
</div>

</body>
</html>